<?php
session_start();
require_once '../includes/db.php';
require_once '../includes/helpers.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

$adminId = $_SESSION['user_id'];
$name = $_SESSION['name'];
$success = '';
$error = '';

// Handle response
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['respond_ticket'])) {
    $ticket_id = $_POST['ticket_id'];
    $message = trim($_POST['message']);
    $status = $_POST['status'];

    if ($message && $status) {
        $stmt = $conn->prepare("INSERT INTO responses (ticket_id, admin_id, message) VALUES (?, ?, ?)");
        $stmt->execute([$ticket_id, $adminId, $message]);

        $stmt2 = $conn->prepare("UPDATE tickets SET status = ? WHERE id = ?");
        $stmt2->execute([$status, $ticket_id]);

        $success = "Response sent and ticket updated.";
    } else {
        $error = "Message and status are required.";
    }
}

// Fetch ticket data
$tickets = $conn->query("
    SELECT t.*, u.name AS student_name
    FROM tickets t
    JOIN users u ON t.user_id = u.id
    ORDER BY t.created_at DESC
")->fetchAll();

// Ticket stats
$counts = [
    'total' => $conn->query("SELECT COUNT(*) FROM tickets")->fetchColumn(),
    'open' => $conn->query("SELECT COUNT(*) FROM tickets WHERE status = 'open'")->fetchColumn(),
    'in_progress' => $conn->query("SELECT COUNT(*) FROM tickets WHERE status = 'in_progress'")->fetchColumn(),
    'closed' => $conn->query("SELECT COUNT(*) FROM tickets WHERE status = 'closed'")->fetchColumn()
];
?>

<?php include '../includes/header.php'; ?>

<div class="container mt-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h3>Welcome, Admin <?= htmlspecialchars($name) ?></h3>
        <a href="../logout.php" class="btn btn-outline-danger">Logout</a>
    </div>

    <!-- Stats Cards -->
    <div class="row mb-4">
        <div class="col-md-3">
            <div class="card text-white bg-primary">
                <div class="card-body">
                    <h5>Total Tickets</h5>
                    <h3><?= $counts['total'] ?></h3>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card text-white bg-warning">
                <div class="card-body">
                    <h5>Open</h5>
                    <h3><?= $counts['open'] ?></h3>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card text-white bg-info">
                <div class="card-body">
                    <h5>In Progress</h5>
                    <h3><?= $counts['in_progress'] ?></h3>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card text-white bg-success">
                <div class="card-body">
                    <h5>Closed</h5>
                    <h3><?= $counts['closed'] ?></h3>
                </div>
            </div>
        </div>
    </div>

    <!-- Chart -->
    <div class="card mb-4">
        <div class="card-header bg-dark text-white">Ticket Status Overview</div>
        <div class="card-body">
            <div style="max-width: 400px; margin: auto;">
                <canvas id="ticketChart" height="300"></canvas>
            </div>
        </div>
    </div>

    <!-- Alerts -->
    <?php if ($success): ?>
        <div class="alert alert-success"><?= $success ?></div>
    <?php endif; ?>
    <?php if ($error): ?>
        <div class="alert alert-danger"><?= $error ?></div>
    <?php endif; ?>

    <!-- Ticket Table -->
    <div class="card">
        <div class="card-header bg-dark text-white">All Tickets</div>
        <div class="card-body p-0">
            <?php if ($tickets): ?>
                <table class="table table-striped table-hover mb-0">
                    <thead class="table-dark">
                        <tr>
                            <th>Student</th>
                            <th>Subject</th>
                            <th>Status</th>
                            <th>Created</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($tickets as $ticket): ?>
                            <tr>
                                <td><?= htmlspecialchars($ticket['student_name']) ?></td>
                                <td><?= htmlspecialchars($ticket['subject']) ?></td>
                                <td><span
                                        class="badge bg-<?= getStatusColor($ticket['status']) ?>"><?= $ticket['status'] ?></span>
                                </td>
                                <td><?= date('M d, Y H:i', strtotime($ticket['created_at'])) ?></td>
                                <td>
                                    <button class="btn btn-sm btn-primary" data-bs-toggle="modal"
                                        data-bs-target="#respondModal<?= $ticket['id'] ?>">Respond</button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p class="p-3 text-muted">No tickets found.</p>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Respond Modals -->
<?php foreach ($tickets as $ticket): ?>
    <?php
    $responseStmt = $conn->prepare("SELECT * FROM responses WHERE ticket_id = ?");
    $responseStmt->execute([$ticket['id']]);
    $responses = $responseStmt->fetchAll();
    ?>
    <div class="modal fade" id="respondModal<?= $ticket['id'] ?>" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
            <form method="POST" class="modal-content">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title">Respond to Ticket</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <input type="hidden" name="respond_ticket" value="1">
                    <input type="hidden" name="ticket_id" value="<?= $ticket['id'] ?>">

                    <div class="mb-2">
                        <strong>Student:</strong> <?= htmlspecialchars($ticket['student_name']) ?><br>
                        <strong>Subject:</strong> <?= htmlspecialchars($ticket['subject']) ?>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Your Response</label>
                        <textarea name="message" class="form-control" rows="4" required></textarea>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Update Status</label>
                        <select name="status" class="form-select" required>
                            <option value="open" <?= $ticket['status'] === 'open' ? 'selected' : '' ?>>Open</option>
                            <option value="in_progress" <?= $ticket['status'] === 'in_progress' ? 'selected' : '' ?>>In
                                Progress</option>
                            <option value="closed" <?= $ticket['status'] === 'closed' ? 'selected' : '' ?>>Closed</option>
                        </select>
                    </div>

                    <?php if ($responses): ?>
                        <div class="mt-3 border-top pt-2">
                            <h6>Previous Responses</h6>
                            <ul class="list-group">
                                <?php foreach ($responses as $res): ?>
                                    <li class="list-group-item">
                                        <small
                                            class="text-muted"><?= date('M d, Y H:i', strtotime($res['created_at'])) ?></small><br>
                                        <?= nl2br(htmlspecialchars($res['message'])) ?>
                                    </li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Send Response</button>
                </div>
            </form>
        </div>
    </div>
<?php endforeach; ?>

<!-- Chart.js CDN -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    const ctx = document.getElementById('ticketChart').getContext('2d');
    new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: ['Open', 'In Progress', 'Closed'],
            datasets: [{
                label: 'Ticket Status',
                data: [<?= $counts['open'] ?>, <?= $counts['in_progress'] ?>, <?= $counts['closed'] ?>],
                backgroundColor: ['#ffc107', '#17a2b8', '#28a745']
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'top',
                }
            }
        }
    });
</script>

<?php include '../includes/footer.php'; ?>