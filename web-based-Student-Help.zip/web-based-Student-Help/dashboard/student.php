<?php
session_start();
require_once '../includes/db.php';

// Only allow logged-in students
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'student') {
    header("Location: ../login.php");
    exit;
}

$userId = $_SESSION['user_id'];
$name = $_SESSION['name'];
$success = '';
$error = '';

// Handle ticket submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_ticket'])) {
    $subject = trim($_POST['subject']);
    $message = trim($_POST['message']);

    if ($subject && $message) {
        $stmt = $conn->prepare("INSERT INTO tickets (user_id, subject, message) VALUES (?, ?, ?)");
        $stmt->execute([$userId, $subject, $message]);
        $success = "Ticket submitted successfully.";
    } else {
        $error = "Subject and message cannot be empty.";
    }
}

// Fetch student's tickets
$stmt = $conn->prepare("SELECT * FROM tickets WHERE user_id = ? ORDER BY created_at DESC");
$stmt->execute([$userId]);
$tickets = $stmt->fetchAll();
?>

<?php include '../includes/header.php'; ?>

<div class="container mt-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h3>Hello, <?= htmlspecialchars($name) ?></h3>
        <a href="../logout.php" class="btn btn-outline-danger">Logout</a>
    </div>

    <?php if ($success): ?>
            <div class="alert alert-success"><?= $success ?></div>
    <?php endif; ?>
    <?php if ($error): ?>
            <div class="alert alert-danger"><?= $error ?></div>
    <?php endif; ?>

    <button class="btn btn-primary mb-3" data-bs-toggle="modal" data-bs-target="#ticketModal">Submit New Ticket</button>

    <div class="card">
        <div class="card-header bg-secondary text-white">Your Tickets</div>
        <div class="card-body">
            <?php if (count($tickets) > 0): ?>
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Subject</th>
                                <th>Status</th>
                                <th>Created</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($tickets as $ticket): ?>
                                    <tr>
                                        <td><?= htmlspecialchars($ticket['subject']) ?></td>
                                        <td><span class="badge bg-<?= getStatusColor($ticket['status']) ?>"><?= $ticket['status'] ?></span></td>
                                        <td><?= date('M d, Y H:i', strtotime($ticket['created_at'])) ?></td>
                                        <td>
                                            <button class="btn btn-sm btn-outline-info" data-bs-toggle="modal" data-bs-target="#viewModal<?= $ticket['id'] ?>">View</button>
                                        </td>
                                    </tr>

                                    <?php
                                    $responseStmt = $conn->prepare("
                                SELECT r.message, r.created_at, u.name AS admin_name
                                FROM responses r
                                JOIN users u ON r.admin_id = u.id
                                WHERE r.ticket_id = ?
                                ORDER BY r.created_at ASC
                            ");
                                    $responseStmt->execute([$ticket['id']]);
                                    $responses = $responseStmt->fetchAll();
                                    ?>

                                    <!-- Response View Modal -->
                                    <div class="modal fade" id="viewModal<?= $ticket['id'] ?>" tabindex="-1">
                                        <div class="modal-dialog modal-dialog-scrollable">
                                            <div class="modal-content">
                                                <div class="modal-header bg-info text-white">
                                                    <h5 class="modal-title">Ticket: <?= htmlspecialchars($ticket['subject']) ?></h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                                </div>
                                                <div class="modal-body">
                                                    <p><strong>Your Message:</strong><br><?= nl2br(htmlspecialchars($ticket['message'])) ?></p>
                                                    <hr>
                                                    <?php if ($responses): ?>
                                                            <h6>Admin Responses:</h6>
                                                            <?php foreach ($responses as $resp): ?>
                                                                    <div class="mb-3">
                                                                        <div class="border rounded p-2 bg-light">
                                                                            <small><strong><?= htmlspecialchars($resp['admin_name']) ?></strong> on <?= date('M d, Y H:i', strtotime($resp['created_at'])) ?></small>
                                                                            <p class="mb-0"><?= nl2br(htmlspecialchars($resp['message'])) ?></p>
                                                                        </div>
                                                                    </div>
                                                            <?php endforeach; ?>
                                                    <?php else: ?>
                                                            <p class="text-muted">No response yet.</p>
                                                    <?php endif; ?>
                                                </div>
                                                <div class="modal-footer">
                                                    <button class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
            <?php else: ?>
                    <p class="text-muted">No tickets submitted yet.</p>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Ticket Submission Modal -->
<div class="modal fade" id="ticketModal" tabindex="-1" aria-labelledby="ticketModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <form method="POST" class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title" id="ticketModalLabel">New Help Desk Ticket</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <input type="hidden" name="submit_ticket" value="1">
                <div class="mb-3">
                    <label class="form-label">Subject</label>
                    <input type="text" name="subject" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Message</label>
                    <textarea name="message" class="form-control" rows="4" required></textarea>
                </div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="submit" class="btn btn-primary">Submit Ticket</button>
            </div>
        </form>
    </div>
</div>

<?php include '../includes/footer.php'; ?>

<?php
// Helper to style status badge
function getStatusColor($status)
{
    return match ($status) {
        'open' => 'warning',
        'in_progress' => 'info',
        'closed' => 'success',
        default => 'secondary',
    };
}
?>
