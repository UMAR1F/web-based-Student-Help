<?php
session_start();
require_once 'includes/db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$isAdmin = $_SESSION['role'] === 'admin';
$success = '';
$error = '';

// Handle new announcement (admin only)
if ($isAdmin && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title']);
    $message = trim($_POST['message']);

    if ($title && $message) {
        $stmt = $conn->prepare("INSERT INTO announcements (title, message) VALUES (?, ?)");
        $stmt->execute([$title, $message]);
        $success = "Announcement posted successfully.";
    } else {
        $error = "Title and message are required.";
    }
}

// Fetch all announcements
$announcements = $conn->query("SELECT * FROM announcements ORDER BY created_at DESC")->fetchAll();
?>

<?php include 'includes/header.php'; ?>

<div class="container mt-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h3>Announcements</h3>
        <a href="dashboard/<?= $_SESSION['role'] ?>.php" class="btn btn-outline-primary">Back to Dashboard</a>
    </div>

    <?php if ($isAdmin): ?>
        <div class="card mb-4">
            <div class="card-header bg-primary text-white">Post New Announcement</div>
            <div class="card-body">
                <?php if ($success): ?>
                    <div class="alert alert-success"><?= $success ?></div>
                <?php endif; ?>
                <?php if ($error): ?>
                    <div class="alert alert-danger"><?= $error ?></div>
                <?php endif; ?>

                <form method="POST">
                    <div class="mb-3">
                        <label class="form-label">Title</label>
                        <input type="text" name="title" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Message</label>
                        <textarea name="message" rows="4" class="form-control" required></textarea>
                    </div>
                    <button type="submit" class="btn btn-success">Post</button>
                </form>
            </div>
        </div>
    <?php endif; ?>

    <?php if ($announcements): ?>
        <?php foreach ($announcements as $a): ?>
            <div class="card mb-3">
                <div class="card-header bg-secondary text-white">
                    <strong><?= htmlspecialchars($a['title']) ?></strong>
                    <span class="float-end"><?= date('M d, Y H:i', strtotime($a['created_at'])) ?></span>
                </div>
                <div class="card-body">
                    <p><?= nl2br(htmlspecialchars($a['message'])) ?></p>
                </div>
            </div>
        <?php endforeach; ?>
    <?php else: ?>
        <p class="text-muted">No announcements yet.</p>
    <?php endif; ?>
</div>

<?php include 'includes/footer.php'; ?>