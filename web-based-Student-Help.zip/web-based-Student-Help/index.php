<?php include 'includes/header.php'; ?>
<div class="container mt-5">
    <div class="text-center">
        <h1 class="display-4">Welcome to the Student Help Desk</h1>
        <p class="lead">Submit queries, get help, and communicate with department staff efficiently.</p>
        <a href="register.php" class="btn btn-primary btn-lg m-2">Get Started</a>
        <a href="login.php" class="btn btn-outline-secondary btn-lg m-2">Login</a>
    </div>
</div>