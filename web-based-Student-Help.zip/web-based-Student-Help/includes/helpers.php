<?php
if (!function_exists('getStatusColor')) {
    function getStatusColor($status)
    {
        return match ($status) {
            'open' => 'warning',
            'in_progress' => 'info',
            'closed' => 'success',
            default => 'secondary',
        };
    }
}
