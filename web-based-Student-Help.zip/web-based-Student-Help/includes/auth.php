<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Redirect to login if not logged in
function requireLogin()
{
    if (!isset($_SESSION['user_id'])) {
        header("Location: /login.php");
        exit;
    }
}

// Redirect to login or deny access if wrong role
function requireRole($role)
{
    requireLogin();
    if ($_SESSION['role'] !== $role) {
        header("Location: /login.php");
        exit;
    }
}
