<!-- Footer HTML if any -->
<footer class="text-center mt-5 mb-3 text-muted">
    &copy; <?= date('Y') ?> Student Help Desk. All rights reserved.
</footer>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
